using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class NeedleControl : MonoBehaviour
{

    float speed = 0.8f;
    Vector3 position;
    public Camera mainCamera;
    public Camera sideCamera;
    public Transform customPivot;
    public AudioSource soundBitty;


    // Start is called before the first frame update
    void Start()
    {
        mainCamera.enabled = true;
	sideCamera.enabled = false;
        soundBitty = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

        position = this.transform.position;

        if (Input.GetKey(KeyCode.UpArrow))
        {
            transform.position += transform.forward * Time.deltaTime * speed;
            //transform.Translate(0, Time.deltaTime * speed, 0);
         
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            //transform.Translate(0, -1 * Time.deltaTime * speed, 0);
            transform.position -= transform.forward * Time.deltaTime * speed;
	    // float distance = (go2.transform.position - go1.transform.position).magnitude;
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if (speed > 0)
            {
                speed-= 0.1f;
            }
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            speed+=0.1f;
        }

        // change camera
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SwitchCamera();
        }

        if (Input.GetKey(KeyCode.D)) // upward angle
        {
	    // code obtained from StackOverflow
            transform.RotateAround(customPivot.position, Vector3.up, 2* Time.deltaTime);
	}

	else if (Input.GetKey(KeyCode.A)) // downward angle
        {

            transform.RotateAround(customPivot.position, Vector3.down, 2* Time.deltaTime);
	}

    }

    public void SwitchCamera()
    {
	mainCamera.enabled = !(mainCamera.enabled);
	sideCamera.enabled = !(sideCamera.enabled);
    }

    void OnTriggerEnter(Collider other) // recognize collisions
    {
        if (other.gameObject.CompareTag("Obstacle"))
        {
            other.gameObject.SetActive(false);
            //count++;
            //SetCountText();
        }
    }
    

    void OnCollisionEnter( Collision collision )
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
        	soundBitty.Play();
	}
    }
}
